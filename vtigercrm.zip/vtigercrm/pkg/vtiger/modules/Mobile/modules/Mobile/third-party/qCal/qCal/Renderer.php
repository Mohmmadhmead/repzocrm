<?php
abstract class qCal_Renderer {

	abstract public function render(qCal_Component $component);

}